# coding: utf-8
import time
import xbmc
import os
import xbmcgui
import urllib2
import webbrowser


def menuoptions():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
        function2,
        function3,
		function4,
		function5,
		function6,
		function7,
		function8,
		function9,
		function10,
		function11,
		function12,
		function13,
		function14,
		function15,
		function16,
		function17,
		function18,
		#function19,
		#function20,
		#function21
        )
        
    call = dialog.select('[COLOR=red]Poodle - Pair-ing System[/COLOR]', [
	'[COLOR=gold]=== אישור חשבונות Debrid ===[/COLOR]',
	'[COLOR=aqua](1) ResolveUrl[/COLOR]',
	'[COLOR=aqua](2) Seren[/COLOR]',
    '[COLOR=aqua](3) Shadow[/COLOR]',
	'[COLOR=aqua](4) Victory[/COLOR]',
    '[COLOR=gold]=== אישור חשבונות Trakt ===[/COLOR]',
    '[COLOR=aqua](1) The Crew[/COLOR]',
    '[COLOR=aqua](2) Fen[/COLOR]',
	'[COLOR=aqua](4) Seren[/COLOR]',
	'[COLOR=aqua](5) Victory[/COLOR]',
	'[COLOR=aqua](6) Elementum[/COLOR]',
    '[COLOR=gold]=== הגדרת חשבון Telemedia ===[/COLOR]',
	'[COLOR=aqua](1) כניסה לחשבון[/COLOR]',
	'[COLOR=aqua](2) ניקוי הכל[/COLOR]',])



    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-18]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def function1(): 0

def function2():
    xbmc.executebuiltin("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")

def function3():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.seren/?action=authRealDebrid)")
    
def function4():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.shadow?mode=138&url=www)")

def function5():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.allmoviesin?mode=138&url=www)")
        
def function6(): 0

def function7():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.thecrew/?action=authTrakt)")

def function8():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fen/?mode=trakt_authenticate)")

def function9():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.seren/?action=authTrakt)")

def function10():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.allmoviesin?mode=157&url=False)")

def function11():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.elementum/trakt/authorize)")

def function12(): 0

def function13():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")

def function14():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=48&url=www)")

def function15():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.directv.com/sports/mlb_schedules' ) )
    else:
        opensite = webbrowser . open('https://www.directv.com/sports/mlb_schedules')		

def function16():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://schedule.boxingscene.com/' ) )
    else:
        opensite = webbrowser . open('https://schedule.boxingscene.com/')	

def function17():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://www.ufc.com/schedule' ) )
    else:
        opensite = webbrowser . open('http://www.ufc.com/schedule/')

def function18():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://t.me/joinchat/EcAW2RKp5wnCiogp_Fs7mA' ) )
    else:
        opensite = webbrowser . open('https://t.me/joinchat/Hz_GFxEIgPnyeS0NqGv2Kg/')	
		
menuoptions()
