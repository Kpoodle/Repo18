# -*- coding: utf-8 -*-
import requests

cdn = 'c253e23f7e41d002fbda959c65f120b2'
response = requests.post('https://www.karaoke.co.il/api.php', data={'action': 'playbackByCDN',	'cdn': cdn}, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36'})
print (response.json()['data']['playback'].replace('mp3', 'mp4'))