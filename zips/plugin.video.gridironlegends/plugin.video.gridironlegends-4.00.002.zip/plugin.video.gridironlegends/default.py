#########################################
############CODE BY @NEMZZY668###########
#########################################

import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,base64,json,time,requests,resolveurl
from resources.libs.common_addon import Addon
#from HTMLParser import HTMLParser
from datetime import datetime
from bs4 import BeautifulSoup
reload(sys)
sys.setdefaultencoding("utf-8")


addon_id            = 'plugin.video.gridironlegends'
addon               = Addon(addon_id, sys.argv)
baseurl             = base64.b64decode(b'aHR0cDovL25vbGVkeW5hc3R5Lnh5ei9ncmlkaXJvbi9ncmlkaXJvbm1haW4ueG1s')
selfAddon           = xbmcaddon.Addon(id=addon_id)
AddonTitle          = '[COLOR gold][B]Gridiron Legends[/B][/COLOR]'
addonPath           = os.path.join(os.path.join(xbmc.translatePath('special://home'), 'addons'),'plugin.video.gridironlegends')
fanarts             = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'fanart.jpg'))
fanart              = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'fanart.jpg'))
icon                = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
Addonicon                = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
dp                  = xbmcgui.DialogProgress()
dialog              = xbmcgui.Dialog()
Current_Downloads   =  ''
messagetext         = 'https://pastebin.com/raw/vJN3LNcM'
youtubeapi          = base64.b64decode(b'QUl6YVN5QTIweUx1T2FaZWVNUG1MZFY5SDJMaUhJV0FwMmxGYWZj')


def popup():

	message= open_msg(messagetext)
	if len(message)>1:
		path = xbmcaddon.Addon().getAddonInfo('path')
		comparefile = os.path.join(os.path.join(path,''), 'compare.txt')
		r = open(comparefile)
		compfile = r.read()       
		if compfile == message:pass
		else:
			showText('[COLOR gold][B]Gridiron Legends Information[/B][/COLOR]', message)
			text_file = open(comparefile, "w")
			text_file.write(message)
			text_file.close()

def open_msg(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36')
		response = urllib2.urlopen(req, timeout=5)
		link=response.read()
		response.close()
		return link
	except:quit()
	
def OpenLink(url):

	link = requests.get(url).content
	return link

def SET_VIEW():

    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])
    if version >= 16.0 and version <= 16.9:
        codename = 'Jarvis'
    elif version >= 17.0 and version <= 17.9:
        codename = 'Krypton'
    elif version >= 18.0 and version <= 18.9:
        codename = 'Leia'
    else: codename = "Decline"
    
    if codename == "Jarvis":
        xbmc.executebuiltin('Container.SetViewMode(50)')
    elif codename == "Krypton":
        xbmc.executebuiltin('Container.SetViewMode(55)')
    elif codename == "Leia":
        xbmc.executebuiltin('Container.SetViewMode(55)')
    else: xbmc.executebuiltin('Container.SetViewMode(50)')


def GetMenu():

	url = baseurl
	url2=url
	popup()
	gettime = int(datetime.now().strftime('%H%M'))
	if (gettime >= 0000) and (gettime <= 1159): a = "Morning"
	elif (gettime >= 1200) and (gettime <= 1759): a = "Afternoon"
	else: a = "Evening"
	addStandardLink('[COLOR yellow]Good[COLOR aqua] ' + str(a) + '[COLOR yellow] From Gridiron Legends[/COLOR]','url','12',icon,fanarts)
	addStandardLink("[COLOR yellow]---------------------------------------[/COLOR]",'url2',999,icon,fanarts)
	link=OpenLink(baseurl)
	match= re.findall('<item>(.+?)</item>',link,flags=re.DOTALL)
	for item in match:
		try:
			if '<m3u>' in item:
				name=re.findall('<title>(.+?)</title>',item,flags=re.DOTALL)[0]
				iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',item,flags=re.DOTALL)[0]
				fanart=re.findall('<fanart>(.+?)</fanart>',item,flags=re.DOTALL)[0]
				url=re.findall('<m3u>(.+?)</m3u>',item,flags=re.DOTALL)[0]
				addDir(name,url,11,iconimage,fanart)
			elif '<allsports>' in item:
				name=re.findall('<title>(.+?)</title>',item,flags=re.DOTALL)[0]
				iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',item,flags=re.DOTALL)[0]
				fanart=re.findall('<fanart>(.+?)</fanart>',item,flags=re.DOTALL)[0]
				url=re.findall('<allsports>(.+?)</allsports>',item,flags=re.DOTALL)[0]
				addDir(name,url,9,iconimage,fanart)
			elif '<folder>'in item:
				data=re.findall('<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>',item,flags=re.DOTALL)
				for name,url,iconimage,fanart in data:
					addDir(name,url,1,iconimage,fanart)
			else:
				links=re.findall('<link>(.+?)</link>',item,flags=re.DOTALL)
				if len(links)==1:
					data=re.findall('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
					lcount=len(match)
					for name,url,iconimage,fanart in data:
						addLink(name,url,1000,iconimage,fanart)
				elif len(links)>1:
					name=re.findall('<title>(.+?)</title>',item,flags=re.DOTALL)[0]
					iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',item,flags=re.DOTALL)[0]
					fanart=re.findall('<fanart>(.+?)</fanart>',item,flags=re.DOTALL)[0]
					addLink(name,url2,3,iconimage,fanart)
		except:pass

	xbmc.executebuiltin('Container.SetViewMode(55)')

def GetContent(name,url,iconimage,fanart):
	dialog = xbmcgui.Dialog()
	url3=url
	link=OpenLink(url)
	match= re.findall('<item>(.+?)</item>',link,flags=re.DOTALL)
	for item in match:
		try:
			if '<m3u>' in item:
				name=re.findall('<title>(.+?)</title>',item,flags=re.DOTALL)[0]
				iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',item,flags=re.DOTALL)[0]
				fanart=re.findall('<fanart>(.+?)</fanart>',item,flags=re.DOTALL)[0]
				url=re.findall('<m3u>(.+?)</m3u>',item,flags=re.DOTALL)[0]
				addDir(name,url,11,iconimage,fanart)
			elif '<image>' in item:
					name=re.findall('<title>(.+?)</title>',item,flags=re.DOTALL)[0]
					iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',item,flags=re.DOTALL)[0]            
					fanart=re.findall('<fanart>(.+?)</fanart>',item,flags=re.DOTALL)[0]
					url=re.findall('<image>(.+?)</image>',item,flags=re.DOTALL)[0]
					addDir(name,url,9,iconimage,fanart)
			elif '<youtube>' in item:
					name=re.findall('<title>(.+?)</title>',item,flags=re.DOTALL)[0]
					iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',item,flags=re.DOTALL)[0]            
					fanart=re.findall('<fanart>(.+?)</fanart>',item,flags=re.DOTALL)[0]
					url=re.findall('<youtube>(.+?)</youtube>',item,flags=re.DOTALL)[0]
					addDir(name,url,5,iconimage,fanart)
			elif '<yoursports>' in item:
					name=re.findall('<title>(.+?)</title>',item,flags=re.DOTALL)[0]
					iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',item,flags=re.DOTALL)[0]            
					fanart=re.findall('<fanart>(.+?)</fanart>',item,flags=re.DOTALL)[0]
					url=re.findall('<yoursports>(.+?)</yoursports>',item,flags=re.DOTALL)[0]
					addDir(name,url,6,iconimage,fanart)
			elif '<yourlive>' in item:
					name=re.findall('<title>(.+?)</title>',item,flags=re.DOTALL)[0]
					iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',item,flags=re.DOTALL)[0]            
					fanart=re.findall('<fanart>(.+?)</fanart>',item,flags=re.DOTALL)[0]
					url=re.findall('<yourlive>(.+?)</yourlive>',item,flags=re.DOTALL)[0]
					addDir(name,url,8,iconimage,fanart)
			elif '<folder>'in item:
				data=re.findall('<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>',item,flags=re.DOTALL)
				for name,url,iconimage,fanart in data:
						addDir(name,url,1,iconimage,fanart)
			else:
				links=re.findall('<link>(.+?)</link>',item,flags=re.DOTALL)
				if len(links)==1:
					data=re.findall('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>',item,flags=re.DOTALL)
					lcount=len(match)
					for name,url,iconimage,fanart in data:
						addLink(name,url,1000,iconimage,fanart)
				elif len(links)>1:
					name=re.findall('<title>(.+?)</title>',item,flags=re.DOTALL)[0]
					iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',item,flags=re.DOTALL)[0]
					fanart=re.findall('<fanart>(.+?)</fanart>',item,flags=re.DOTALL)[0]
					addLink(name,url3,3,iconimage,fanart)
		except:pass

	xbmc.executebuiltin('Container.SetViewMode(55)')


####################################################
## THE SCRAPPERS
####################################################




####################################################
## THE IMPORTANT STUFF
####################################################

def CLEANUP(text):

	text = str(text)
	text = text.replace('\\r','')
	text = text.replace('\\n','')
	text = text.replace('\\t','')
	text = text.replace('\\','')
	text = text.replace('<br />','\n')
	text = text.replace('<hr />','')
	text = text.replace('&#039;',"'")
	text = text.replace('&#39;',"'")
	text = text.replace('&quot;','"')
	text = text.replace('&rsquo;',"'")
	text = text.replace('&amp;',"&")
	text = text.replace('&#8211;',"&")
	text = text.replace('&#8217;',"'")
	text = text.replace('&#038;',"&")
	text = text.replace('&#8211;',"-")
	text = text.lstrip(' ')
	text = text.lstrip('	')

	return text

def PLAYLINK(name,link,iconimage):
	if 'acestream' in url:
			dialog.notification(AddonTitle, '[COLOR skyblue]Resolve Acestream Link Now[/COLOR]', icon, 5000)
			url1 = "plugin://program.plexus/?url=" + url + "&mode=1&name=acestream+"
			liz = xbmcgui.ListItem(name,iconImage=iconimage, thumbnailImage=iconimage)
			liz.setPath(url)
			xbmc.Player ().play(url1, liz, False)
			quit()
	else:
		try:
			hmf = resolveurl.HostedMediaFile(url=link)
			if hmf.valid_url(): link = hmf.resolve()
			dialog.notification(AddonTitle, '[COLOR yellow]Hunting Link Now Be Patient[/COLOR]', Addonicon, 2500)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path=link))
			quit()
		except Exception, e:
			dialog.notification(AddonTitle,"[B][COLOR yellow]%s[/B][/COLOR]" % str(e),icon,5000)
			quit()

def addDir(name,url,mode,iconimage,fanart,description=''):

	try: description = description.encode(encoding='UTF-8',errors='strict')
	except : pass
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage,)
	liz.setProperty( "fanart_Image", fanart )
	liz.setProperty( "icon_Image", iconimage )
	liz.setInfo('video', {'Plot': description})
	view=xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addLink(name, url, mode, iconimage, fanart, description='',family=''):

	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setProperty( "fanart_Image", fanart )
	liz.setProperty( "icon_Image", iconimage )
	liz.setInfo('video', {'Plot': description})
	liz.setProperty('IsPlayable', 'true')
	view=xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addStandardLink(name, url, mode, iconimage, fanart, description='',family=''):

	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setProperty( "fanart_Image", fanart )
	liz.setProperty( "icon_Image", iconimage )
	liz.setInfo('video', {'Plot': description})
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok
    
def showText(heading, text):

    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            quit()
            return
        except: pass

def GETMULTI(name,url,iconimage):
	dialog = xbmcgui.Dialog()
	streamurl=[]
	streamname=[]
	streamicon=[]
	link=requests.get(url).content
	urls=re.findall('<title>'+re.escape(name)+'</title>(.+?)</item>',link,flags=re.DOTALL)[0]
	iconimage=re.findall('<thumbnail>(.+?)</thumbnail>',urls,flags=re.DOTALL)[0]
	links=re.findall('<link>(.+?)</link>',urls,flags=re.DOTALL)
	i=1
	for sturl in links:
		sturl2=sturl
		if '(' in sturl:
			sturl=sturl.split('(')[0]
			caption=str(sturl2.split('(')[1].replace(')',''))
			streamurl.append(sturl)
			streamname.append(caption)
		else:
			streamurl.append( sturl )
			streamname.append( '[B][COLOR white]Link '+str(i) + '[/COLOR][/B]' )
		i=i+1
	names='[B][COLOR white]'+name+'[/COLOR][/B]'
	dialog = xbmcgui.Dialog()
	select = dialog.select(names,streamname)
	if select < 0: quit()
	else:
		url = streamurl[select]
		stream_url=url
		liz = xbmcgui.ListItem(name,iconImage='DefaultVideo.png', thumbnailImage=iconimage)
		liz.setPath(stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
		dialog.notification(AddonTitle, '[COLOR yellow]Hunting For A Link Now[/COLOR]', icon, 2500)
		time.sleep(1)
		xbmc.Player ().play(stream_url, liz, False)

		
###################################
###################################
############SCRAPERS###############
def YoutubeScrape(url):
	try:
		if not 'https' in url:
			url = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet%2CcontentDetails&maxResults=50&playlistId=' + url + '&key=' + youtubeapi
		data = requests.get(url).json()
		try:
			nextpage = data['nextPageToken']
		except: pass
		grab = data['items']
		for i in grab:
			try:
				title = i['snippet']['title'].encode('utf-8')
				description = i['snippet']['description'].encode('utf-8')
				icon = i['snippet']['thumbnails']['default']['url']
				icon = icon.replace('default','hqdefault')
				url1 = i['contentDetails']['videoId']
				fanart = icon
				url2 = 'plugin://plugin.video.youtube/play/?video_id='+url1
				addLink("[COLOR yellow][B]" + str(title) + "[/B][/COLOR]",str(url2),1000,icon,fanart,description)
			except: pass
		try:
			if '&pageToken=' in url:
				npurl = url.split("&pageToken=",1)[0]
				npurl1 = npurl + '&pageToken=' + nextpage
				xbmc.log(npurl)
				npicon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
				addDir("[COLOR red][B]Next Page --------->[/B][/COLOR]",npurl1,5,NextPageImg,fanart)
			else:
				npurl = url + '&pageToken=' + nextpage
				npicon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
				addDir("[COLOR red][B]Next Page --------->[/B][/COLOR]",npurl,5,NextPageImg,fanart)
		except:pass
	except:pass
	
def YourSportsScraper(url):
	Headers = {'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36' }
	link = requests.get(url,headers=Headers).content
	soup = BeautifulSoup(link, 'html5lib')
	data = soup.find_all('li', class_={'w3-bar w3-text-white w3-padding-small'})
	siteurl = 'http://yoursports.stream/'
	for content in data:
		try:
			title = content.find('span', style={'font-weight:bold;'})
			time = content.find('span', style={'color:#89cded;font-weight:bold;'})
			if not time: time = '[COLOR lime]LIVE[/COLOR]'
			title = title.text
			try:
				time = time.text
			except: pass
			link = content.find_all('a', class_={'w3-button w3-bar-item w3-hover-blue-gray w3-black w3-padding-small w3-border w3-border-blue-gray w3-tiny'})
			pattern = r'''href=['"]([^'"]+)['"].*?title=['"](.*?)['"]'''
			links = re.findall(pattern,str(link),flags=re.DOTALL)
			maintitle = ('%s | %s' % (title,time))
			addStandardLink("[COLOR aqua][B]" + maintitle + "[/B][/COLOR]",'',99999,'https://img.talkandroid.com/uploads/2014/03/mlb_at_bat_icon.png',fanart,'MLB Scraper')
			for link,subtitle in links:
				if not siteurl in link: link = siteurl+link
				addLink("[COLOR yellow][B]" + subtitle + "[/B][/COLOR]",link,7,'https://img.talkandroid.com/uploads/2014/03/mlb_at_bat_icon.png',fanart,'MLB Scraper')
		except: pass
def YouLiveScraper(url):
	dialog.ok("IN","LIVE")
def YourSportsResolve(name,url,iconimage):
	headers = {'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
				'Referer' : url}
	call = url.split('http://yoursports.stream/')[1]
	call = call.replace('mlb','mlb.php')
	apiurl = ('http://yrsprts.xyz/%s' % call)
	apiurl = CLEANUP(apiurl)
	link = requests.get(apiurl,headers=headers).content
	#dialog.ok("URL",str(link))
	playable = re.findall('''var\s+mustave=['"]([^'"]+)['"].*?''',link,flags=re.DOTALL)[0]
	PLAYLINK(name,playable,iconimage)

def AllSportsNole(url):
	ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'
	headers = {'User-Agent': ua}
	c = requests.get(url, headers=headers).content
	content = re.findall('<div class="page-content">(.*?)<div\s+id="comments"',c,flags=re.DOTALL)[0]
	pattern = r'''/span>\s+(.*?)<a\s+href=['"](.*?)['"].*?</a>(.*?)<.*?>(.*?)<'''
	FindallGames = re.findall(pattern,content,flags=re.DOTALL)
	for title, url, lang, time in FindallGames:
		title = CLEANUP(title)
		title = ('%s |[COLOR lime] %s | [COLOR aqua] %s[/COLOR]' % (title,lang,time))
		addLink("[COLOR yellow][B]"+title+"[/B][/COLOR]",url,10,Addonicon,fanarts,'Lets Watch Some Sports')
		
def NolesResolver(name,url):
	ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'
	headers = {'User-Agent': ua}
	c = requests.get(url, headers=headers).content
	iframe = re.findall('''<iframe.*?src=['"](.*?)['"]''',c,flags=re.DOTALL)[0]
	d = requests.get(iframe, headers=headers).content
	play = base64.b64decode(re.findall('''source:\s+window.atob\(['"](.*?)['"]''',d,flags=re.DOTALL)[0])
	FinalLink = ('%s|Referer=%s' % (play,iframe))
	PLAYLINK(name,FinalLink,iconimage)
	
def GetEncodeString(str):

    try:
        import chardet
        str = str.decode(chardet.detect(str)["encoding"]).encode("utf-8")
    except:
        try:
            str = str.encode("utf-8")
        except:
            pass
    return str

def GET_M3U(name,url,iconimage):

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    response=link
    response = response.replace('#AAASTREAM:','#A:')
    response = response.replace('#EXTINF:','#A:')
    matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
    li = []
    for params, display_name, url in matches:
        item_data = {"params": params, "display_name": display_name, "url": url}
        li.append(item_data)
    list = []
    for channel in li:
        item_data = {"display_name": channel["display_name"], "url": channel["url"]}
        matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
        for field, value in matches:
            item_data[field.strip().lower().replace('-', '_')] = value.strip()
        list.append(item_data)
    for channel in list:
        name = GetEncodeString(channel["display_name"])
        url = GetEncodeString(channel["url"])
        url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
        addLink(name ,url, 1000, icon, fanart,'')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]                    
        return param

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None; description=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: fanart=urllib.unquote_plus(params["fanart"])
except: pass
try: description=urllib.unquote_plus(params["description"])
except: pass
 
if mode==None or url==None or len(url)<1: GetMenu()

####################################################
## THE MODES
####################################################

elif mode==1:GetContent(name,url,iconimage,fanart)

elif mode==3:GETMULTI(name,url,iconimage)
elif mode==5:YoutubeScrape(url)
elif mode==6:YourSportsScraper(url)
elif mode==7:YourSportsResolve(name,url,iconimage)
elif mode==8:YouLiveScraper(url)
elif mode==9:AllSportsNole(url)
elif mode==10:NolesResolver(name,url)
elif mode==11:GET_M3U(name,url,iconimage)

elif mode==1000:PLAYLINK(name,url,iconimage)
if mode==None or url==None or len(url)<1: xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=False)
else: xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)

############################################################
## DEBUG CODES
############################################################
# dialog.ok("Debug", str (next_page))
#<a href=\"([^"]*)\">Next</a>
# dialog.notification(AddonTitle, 'Sponsoskyblue By @Nemzzy668', xbmcgui.NOTIFICATION_INFO, 5000)
# str.encode(encoding='UTF-8',errors='strict')
#urllib.urlretrieve ('http://thehill.com/sites/default/files/blogs/trumpmcmaster.jpg')
# |

