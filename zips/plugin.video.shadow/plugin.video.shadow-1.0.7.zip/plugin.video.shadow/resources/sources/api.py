# -*- coding: utf-8 -*-
import requests,re
import time

global global_var,stop_all#global
global_var=[]
stop_all=0

 
from resources.modules.general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
from  resources.modules import cache
try:
    from resources.modules.general import Addon
except:
  import Addon
type=['movie','tv','torrent']

import urllib2,urllib,logging,base64,json


import urllib2,urllib,logging,base64,json


color=all_colors[112]
def get_links(tv_movie,original_title,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    logging.warning('Get API')
    x=requests.get("https://torrentapi.org/pubapi_v2.php?app_id=me&get_token=get_token",headers=base_header).json()
    token=x['token']
    if tv_movie=='movie':
     search_url=((clean_name(original_title,1).replace(' ','%20')+'%20'+show_original_year)).lower()
    elif tv_movie=='tv':
     search_url=((clean_name(original_title,1).replace(' ','%20')+'%20s'+season_n+'e'+episode_n)).lower()
    time.sleep(0.4)
  
    y=requests.get("https://torrentapi.org/pubapi_v2.php?app_id=me&mode=search&search_string=%s&token=%s&limit=100&format=json_extended"%(search_url,token),headers=base_header).json()

    
    for results in y['torrent_results']:
        if stop_all==1:
            break
        nam=results['title']
        size=(int(results['size'])/(1024*1024*1024))
        peer=results['leechers']
        seed=results['seeders']
        links=results['download']
        if '4k' in nam:
              res='2160'
        elif '2160' in nam:
              res='2160'
        elif '1080' in nam:
                  res='1080'
        elif '720' in nam:
              res='720'
        elif '480' in nam:
              res='480'
        elif '360' in nam:
              res='360'
        else:
              res='HD'
        max_size=int(Addon.getSetting("size_limit"))
     
     
        if (size)<max_size:
            all_links.append((nam,links,str(size),res))

            global_var=all_links
    return global_var